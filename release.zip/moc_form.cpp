/****************************************************************************
** Meta object code from reading C++ file 'form.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Calculator/form.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'form.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Form_t {
    QByteArrayData data[42];
    char stringdata0[822];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Form_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Form_t qt_meta_stringdata_Form = {
    {
QT_MOC_LITERAL(0, 0, 4), // "Form"
QT_MOC_LITERAL(1, 5, 22), // "number_str_recieveData"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 3), // "str"
QT_MOC_LITERAL(4, 33, 21), // "first_str_recieveData"
QT_MOC_LITERAL(5, 55, 22), // "second_str_recieveData"
QT_MOC_LITERAL(6, 78, 22), // "result_str_recieveData"
QT_MOC_LITERAL(7, 101, 17), // "n_str_recieveData"
QT_MOC_LITERAL(8, 119, 17), // "m_str_recieveData"
QT_MOC_LITERAL(9, 137, 25), // "operation_str_recieveData"
QT_MOC_LITERAL(10, 163, 19), // "key_str_recieveData"
QT_MOC_LITERAL(11, 183, 18), // "p1_str_recieveData"
QT_MOC_LITERAL(12, 202, 18), // "p2_str_recieveData"
QT_MOC_LITERAL(13, 221, 18), // "p3_str_recieveData"
QT_MOC_LITERAL(14, 240, 18), // "p4_str_recieveData"
QT_MOC_LITERAL(15, 259, 18), // "p5_str_recieveData"
QT_MOC_LITERAL(16, 278, 18), // "t0_int_recieveData"
QT_MOC_LITERAL(17, 297, 1), // "i"
QT_MOC_LITERAL(18, 299, 18), // "t1_int_recieveData"
QT_MOC_LITERAL(19, 318, 18), // "t2_int_recieveData"
QT_MOC_LITERAL(20, 337, 18), // "t3_int_recieveData"
QT_MOC_LITERAL(21, 356, 18), // "n_char_recieveData"
QT_MOC_LITERAL(22, 375, 18), // "m_char_recieveData"
QT_MOC_LITERAL(23, 394, 25), // "number_double_recieveData"
QT_MOC_LITERAL(24, 420, 1), // "d"
QT_MOC_LITERAL(25, 422, 24), // "first_double_recieveData"
QT_MOC_LITERAL(26, 447, 25), // "second_double_recieveData"
QT_MOC_LITERAL(27, 473, 25), // "result_double_recieveData"
QT_MOC_LITERAL(28, 499, 20), // "n_double_recieveData"
QT_MOC_LITERAL(29, 520, 20), // "m_double_recieveData"
QT_MOC_LITERAL(30, 541, 27), // "number_size_int_recieveData"
QT_MOC_LITERAL(31, 569, 21), // "first_int_recieveData"
QT_MOC_LITERAL(32, 591, 22), // "result_int_recieveData"
QT_MOC_LITERAL(33, 614, 17), // "n_int_recieveData"
QT_MOC_LITERAL(34, 632, 17), // "m_int_recieveData"
QT_MOC_LITERAL(35, 650, 20), // "mode_int_recieveData"
QT_MOC_LITERAL(36, 671, 19), // "num_int_recieveData"
QT_MOC_LITERAL(37, 691, 23), // "equally_int_recieveData"
QT_MOC_LITERAL(38, 715, 25), // "direction_int_recieveData"
QT_MOC_LITERAL(39, 741, 20), // "zero_int_recieveData"
QT_MOC_LITERAL(40, 762, 23), // "currentPath_recieveData"
QT_MOC_LITERAL(41, 786, 35) // "combinatorics_name_Path_recie..."

    },
    "Form\0number_str_recieveData\0\0str\0"
    "first_str_recieveData\0second_str_recieveData\0"
    "result_str_recieveData\0n_str_recieveData\0"
    "m_str_recieveData\0operation_str_recieveData\0"
    "key_str_recieveData\0p1_str_recieveData\0"
    "p2_str_recieveData\0p3_str_recieveData\0"
    "p4_str_recieveData\0p5_str_recieveData\0"
    "t0_int_recieveData\0i\0t1_int_recieveData\0"
    "t2_int_recieveData\0t3_int_recieveData\0"
    "n_char_recieveData\0m_char_recieveData\0"
    "number_double_recieveData\0d\0"
    "first_double_recieveData\0"
    "second_double_recieveData\0"
    "result_double_recieveData\0"
    "n_double_recieveData\0m_double_recieveData\0"
    "number_size_int_recieveData\0"
    "first_int_recieveData\0result_int_recieveData\0"
    "n_int_recieveData\0m_int_recieveData\0"
    "mode_int_recieveData\0num_int_recieveData\0"
    "equally_int_recieveData\0"
    "direction_int_recieveData\0"
    "zero_int_recieveData\0currentPath_recieveData\0"
    "combinatorics_name_Path_recieveData"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Form[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  199,    2, 0x0a /* Public */,
       4,    1,  202,    2, 0x0a /* Public */,
       5,    1,  205,    2, 0x0a /* Public */,
       6,    1,  208,    2, 0x0a /* Public */,
       7,    1,  211,    2, 0x0a /* Public */,
       8,    1,  214,    2, 0x0a /* Public */,
       9,    1,  217,    2, 0x0a /* Public */,
      10,    1,  220,    2, 0x0a /* Public */,
      11,    1,  223,    2, 0x0a /* Public */,
      12,    1,  226,    2, 0x0a /* Public */,
      13,    1,  229,    2, 0x0a /* Public */,
      14,    1,  232,    2, 0x0a /* Public */,
      15,    1,  235,    2, 0x0a /* Public */,
      16,    1,  238,    2, 0x0a /* Public */,
      18,    1,  241,    2, 0x0a /* Public */,
      19,    1,  244,    2, 0x0a /* Public */,
      20,    1,  247,    2, 0x0a /* Public */,
      21,    1,  250,    2, 0x0a /* Public */,
      22,    1,  253,    2, 0x0a /* Public */,
      23,    1,  256,    2, 0x0a /* Public */,
      25,    1,  259,    2, 0x0a /* Public */,
      26,    1,  262,    2, 0x0a /* Public */,
      27,    1,  265,    2, 0x0a /* Public */,
      28,    1,  268,    2, 0x0a /* Public */,
      29,    1,  271,    2, 0x0a /* Public */,
      30,    1,  274,    2, 0x0a /* Public */,
      31,    1,  277,    2, 0x0a /* Public */,
      32,    1,  280,    2, 0x0a /* Public */,
      33,    1,  283,    2, 0x0a /* Public */,
      34,    1,  286,    2, 0x0a /* Public */,
      35,    1,  289,    2, 0x0a /* Public */,
      36,    1,  292,    2, 0x0a /* Public */,
      37,    1,  295,    2, 0x0a /* Public */,
      38,    1,  298,    2, 0x0a /* Public */,
      39,    1,  301,    2, 0x0a /* Public */,
      40,    1,  304,    2, 0x0a /* Public */,
      41,    1,  307,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Double,   24,
    QMetaType::Void, QMetaType::Double,   24,
    QMetaType::Void, QMetaType::Double,   24,
    QMetaType::Void, QMetaType::Double,   24,
    QMetaType::Void, QMetaType::Double,   24,
    QMetaType::Void, QMetaType::Double,   24,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,

       0        // eod
};

void Form::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Form *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->number_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->first_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->second_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->result_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->n_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->m_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->operation_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->key_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->p1_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->p2_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 10: _t->p3_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->p4_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->p5_str_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->t0_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->t1_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->t2_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->t3_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->n_char_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 18: _t->m_char_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: _t->number_double_recieveData((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 20: _t->first_double_recieveData((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 21: _t->second_double_recieveData((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 22: _t->result_double_recieveData((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 23: _t->n_double_recieveData((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 24: _t->m_double_recieveData((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 25: _t->number_size_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->first_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->result_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->n_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->m_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->mode_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 31: _t->num_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 32: _t->equally_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->direction_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->zero_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: _t->currentPath_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 36: _t->combinatorics_name_Path_recieveData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Form::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_Form.data,
    qt_meta_data_Form,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Form::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Form::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Form.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Form::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 37;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
