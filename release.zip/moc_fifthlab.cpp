/****************************************************************************
** Meta object code from reading C++ file 'fifthlab.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Calculator/fifthlab.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fifthlab.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_fifthlab_t {
    QByteArrayData data[22];
    char stringdata0[402];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_fifthlab_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_fifthlab_t qt_meta_stringdata_fifthlab = {
    {
QT_MOC_LITERAL(0, 0, 8), // "fifthlab"
QT_MOC_LITERAL(1, 9, 28), // "on_pushButton_action_clicked"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 7), // "setData"
QT_MOC_LITERAL(4, 47, 8), // "readData"
QT_MOC_LITERAL(5, 56, 11), // "convertData"
QT_MOC_LITERAL(6, 68, 13), // "calculateData"
QT_MOC_LITERAL(7, 82, 25), // "on_spinBox_1_valueChanged"
QT_MOC_LITERAL(8, 108, 4), // "arg1"
QT_MOC_LITERAL(9, 113, 27), // "on_pushButton_chart_clicked"
QT_MOC_LITERAL(10, 141, 24), // "on_checkBox_stateChanged"
QT_MOC_LITERAL(11, 166, 24), // "on_radioButton_4_clicked"
QT_MOC_LITERAL(12, 191, 24), // "on_radioButton_3_clicked"
QT_MOC_LITERAL(13, 216, 22), // "on_radioButton_clicked"
QT_MOC_LITERAL(14, 239, 26), // "on_radioButton_Gni_clicked"
QT_MOC_LITERAL(15, 266, 26), // "on_radioButton_Gwi_clicked"
QT_MOC_LITERAL(16, 293, 27), // "on_radioButton_load_clicked"
QT_MOC_LITERAL(17, 321, 26), // "on_radioButton_arm_clicked"
QT_MOC_LITERAL(18, 348, 7), // "zeroize"
QT_MOC_LITERAL(19, 356, 9), // "intervals"
QT_MOC_LITERAL(20, 366, 29), // "on_comboBox_formula_activated"
QT_MOC_LITERAL(21, 396, 5) // "index"

    },
    "fifthlab\0on_pushButton_action_clicked\0"
    "\0setData\0readData\0convertData\0"
    "calculateData\0on_spinBox_1_valueChanged\0"
    "arg1\0on_pushButton_chart_clicked\0"
    "on_checkBox_stateChanged\0"
    "on_radioButton_4_clicked\0"
    "on_radioButton_3_clicked\0"
    "on_radioButton_clicked\0"
    "on_radioButton_Gni_clicked\0"
    "on_radioButton_Gwi_clicked\0"
    "on_radioButton_load_clicked\0"
    "on_radioButton_arm_clicked\0zeroize\0"
    "intervals\0on_comboBox_formula_activated\0"
    "index"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_fifthlab[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  104,    2, 0x08 /* Private */,
       3,    0,  105,    2, 0x08 /* Private */,
       4,    0,  106,    2, 0x08 /* Private */,
       5,    0,  107,    2, 0x08 /* Private */,
       6,    0,  108,    2, 0x08 /* Private */,
       7,    1,  109,    2, 0x08 /* Private */,
       9,    0,  112,    2, 0x08 /* Private */,
      10,    1,  113,    2, 0x08 /* Private */,
      11,    0,  116,    2, 0x08 /* Private */,
      12,    0,  117,    2, 0x08 /* Private */,
      13,    0,  118,    2, 0x08 /* Private */,
      14,    0,  119,    2, 0x08 /* Private */,
      15,    0,  120,    2, 0x08 /* Private */,
      16,    0,  121,    2, 0x08 /* Private */,
      17,    0,  122,    2, 0x08 /* Private */,
      18,    0,  123,    2, 0x08 /* Private */,
      19,    0,  124,    2, 0x08 /* Private */,
      20,    1,  125,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,

       0        // eod
};

void fifthlab::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<fifthlab *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_action_clicked(); break;
        case 1: _t->setData(); break;
        case 2: _t->readData(); break;
        case 3: _t->convertData(); break;
        case 4: _t->calculateData(); break;
        case 5: _t->on_spinBox_1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_pushButton_chart_clicked(); break;
        case 7: _t->on_checkBox_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_radioButton_4_clicked(); break;
        case 9: _t->on_radioButton_3_clicked(); break;
        case 10: _t->on_radioButton_clicked(); break;
        case 11: _t->on_radioButton_Gni_clicked(); break;
        case 12: _t->on_radioButton_Gwi_clicked(); break;
        case 13: _t->on_radioButton_load_clicked(); break;
        case 14: _t->on_radioButton_arm_clicked(); break;
        case 15: _t->zeroize(); break;
        case 16: _t->intervals(); break;
        case 17: _t->on_comboBox_formula_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject fifthlab::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_fifthlab.data,
    qt_meta_data_fifthlab,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *fifthlab::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *fifthlab::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_fifthlab.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int fifthlab::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
