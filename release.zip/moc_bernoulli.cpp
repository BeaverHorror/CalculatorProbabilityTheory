/****************************************************************************
** Meta object code from reading C++ file 'bernoulli.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Calculator/bernoulli.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'bernoulli.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Bernoulli_t {
    QByteArrayData data[22];
    char stringdata0[249];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Bernoulli_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Bernoulli_t qt_meta_stringdata_Bernoulli = {
    {
QT_MOC_LITERAL(0, 0, 9), // "Bernoulli"
QT_MOC_LITERAL(1, 10, 9), // "factorial"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 1), // "i"
QT_MOC_LITERAL(4, 23, 4), // "soch"
QT_MOC_LITERAL(5, 28, 1), // "n"
QT_MOC_LITERAL(6, 30, 1), // "m"
QT_MOC_LITERAL(7, 32, 9), // "bernoulli"
QT_MOC_LITERAL(8, 42, 1), // "k"
QT_MOC_LITERAL(9, 44, 1), // "p"
QT_MOC_LITERAL(10, 46, 14), // "exarticulation"
QT_MOC_LITERAL(11, 61, 3), // "str"
QT_MOC_LITERAL(12, 65, 3), // "num"
QT_MOC_LITERAL(13, 69, 17), // "close_recieveData"
QT_MOC_LITERAL(14, 87, 32), // "on_pushButton_decision_1_clicked"
QT_MOC_LITERAL(15, 120, 18), // "xC_int_recieveData"
QT_MOC_LITERAL(16, 139, 18), // "yC_int_recieveData"
QT_MOC_LITERAL(17, 158, 19), // "xGC_int_recieveData"
QT_MOC_LITERAL(18, 178, 19), // "yGC_int_recieveData"
QT_MOC_LITERAL(19, 198, 20), // "xGCW_int_recieveData"
QT_MOC_LITERAL(20, 219, 20), // "yGCW_int_recieveData"
QT_MOC_LITERAL(21, 240, 8) // "location"

    },
    "Bernoulli\0factorial\0\0i\0soch\0n\0m\0"
    "bernoulli\0k\0p\0exarticulation\0str\0num\0"
    "close_recieveData\0on_pushButton_decision_1_clicked\0"
    "xC_int_recieveData\0yC_int_recieveData\0"
    "xGC_int_recieveData\0yGC_int_recieveData\0"
    "xGCW_int_recieveData\0yGCW_int_recieveData\0"
    "location"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Bernoulli[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   79,    2, 0x08 /* Private */,
       4,    2,   82,    2, 0x08 /* Private */,
       7,    3,   87,    2, 0x08 /* Private */,
      10,    2,   94,    2, 0x08 /* Private */,
      13,    1,   99,    2, 0x08 /* Private */,
      14,    0,  102,    2, 0x08 /* Private */,
      15,    1,  103,    2, 0x08 /* Private */,
      16,    1,  106,    2, 0x08 /* Private */,
      17,    1,  109,    2, 0x08 /* Private */,
      18,    1,  112,    2, 0x08 /* Private */,
      19,    1,  115,    2, 0x08 /* Private */,
      20,    1,  118,    2, 0x08 /* Private */,
      21,    0,  121,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Int, QMetaType::Int,    3,
    QMetaType::Int, QMetaType::Int, QMetaType::Int,    5,    6,
    QMetaType::Double, QMetaType::Int, QMetaType::Int, QMetaType::Double,    5,    8,    9,
    QMetaType::Int, QMetaType::QString, QMetaType::Int,   11,   12,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,

       0        // eod
};

void Bernoulli::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Bernoulli *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: { int _r = _t->factorial((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 1: { int _r = _t->soch((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 2: { double _r = _t->bernoulli((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = std::move(_r); }  break;
        case 3: { int _r = _t->exarticulation((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 4: _t->close_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_pushButton_decision_1_clicked(); break;
        case 6: _t->xC_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->yC_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->xGC_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->yGC_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->xGCW_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->yGCW_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->location(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Bernoulli::staticMetaObject = { {
    &QDialog::staticMetaObject,
    qt_meta_stringdata_Bernoulli.data,
    qt_meta_data_Bernoulli,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Bernoulli::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Bernoulli::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Bernoulli.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int Bernoulli::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
