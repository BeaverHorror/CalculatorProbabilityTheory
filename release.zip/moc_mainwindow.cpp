/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Calculator/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[128];
    char stringdata0[2332];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 15), // "number_str_Data"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 3), // "str"
QT_MOC_LITERAL(4, 32, 14), // "first_str_Data"
QT_MOC_LITERAL(5, 47, 15), // "second_str_Data"
QT_MOC_LITERAL(6, 63, 15), // "result_str_Data"
QT_MOC_LITERAL(7, 79, 10), // "n_str_Data"
QT_MOC_LITERAL(8, 90, 10), // "m_str_Data"
QT_MOC_LITERAL(9, 101, 18), // "operation_str_Data"
QT_MOC_LITERAL(10, 120, 12), // "key_str_Data"
QT_MOC_LITERAL(11, 133, 11), // "p1_str_Data"
QT_MOC_LITERAL(12, 145, 11), // "p2_str_Data"
QT_MOC_LITERAL(13, 157, 11), // "p3_str_Data"
QT_MOC_LITERAL(14, 169, 11), // "p4_str_Data"
QT_MOC_LITERAL(15, 181, 11), // "p5_str_Data"
QT_MOC_LITERAL(16, 193, 11), // "t0_int_Data"
QT_MOC_LITERAL(17, 205, 1), // "i"
QT_MOC_LITERAL(18, 207, 11), // "t1_int_Data"
QT_MOC_LITERAL(19, 219, 11), // "t2_int_Data"
QT_MOC_LITERAL(20, 231, 11), // "t3_int_Data"
QT_MOC_LITERAL(21, 243, 11), // "xC_int_Data"
QT_MOC_LITERAL(22, 255, 11), // "yC_int_Data"
QT_MOC_LITERAL(23, 267, 12), // "xGC_int_Data"
QT_MOC_LITERAL(24, 280, 12), // "yGC_int_Data"
QT_MOC_LITERAL(25, 293, 13), // "xGCW_int_Data"
QT_MOC_LITERAL(26, 307, 13), // "yGCW_int_Data"
QT_MOC_LITERAL(27, 321, 13), // "xC_int_B_Data"
QT_MOC_LITERAL(28, 335, 13), // "yC_int_B_Data"
QT_MOC_LITERAL(29, 349, 14), // "xGC_int_B_Data"
QT_MOC_LITERAL(30, 364, 14), // "yGC_int_B_Data"
QT_MOC_LITERAL(31, 379, 15), // "xGCW_int_B_Data"
QT_MOC_LITERAL(32, 395, 15), // "yGCW_int_B_Data"
QT_MOC_LITERAL(33, 411, 14), // "xC_int_Py_Data"
QT_MOC_LITERAL(34, 426, 14), // "yC_int_Py_Data"
QT_MOC_LITERAL(35, 441, 15), // "xGC_int_Py_Data"
QT_MOC_LITERAL(36, 457, 15), // "yGC_int_Py_Data"
QT_MOC_LITERAL(37, 473, 16), // "xGCW_int_Py_Data"
QT_MOC_LITERAL(38, 490, 16), // "yGCW_int_Py_Data"
QT_MOC_LITERAL(39, 507, 14), // "xC_int_Po_Data"
QT_MOC_LITERAL(40, 522, 14), // "yC_int_Po_Data"
QT_MOC_LITERAL(41, 537, 15), // "xGC_int_Po_Data"
QT_MOC_LITERAL(42, 553, 15), // "yGC_int_Po_Data"
QT_MOC_LITERAL(43, 569, 16), // "xGCW_int_Po_Data"
QT_MOC_LITERAL(44, 586, 16), // "yGCW_int_Po_Data"
QT_MOC_LITERAL(45, 603, 11), // "n_char_Data"
QT_MOC_LITERAL(46, 615, 11), // "m_char_Data"
QT_MOC_LITERAL(47, 627, 18), // "number_double_Data"
QT_MOC_LITERAL(48, 646, 1), // "d"
QT_MOC_LITERAL(49, 648, 17), // "first_double_Data"
QT_MOC_LITERAL(50, 666, 18), // "second_double_Data"
QT_MOC_LITERAL(51, 685, 18), // "result_double_Data"
QT_MOC_LITERAL(52, 704, 13), // "n_double_Data"
QT_MOC_LITERAL(53, 718, 13), // "m_double_Data"
QT_MOC_LITERAL(54, 732, 20), // "number_size_int_Data"
QT_MOC_LITERAL(55, 753, 14), // "first_int_Data"
QT_MOC_LITERAL(56, 768, 15), // "result_int_Data"
QT_MOC_LITERAL(57, 784, 10), // "n_int_Data"
QT_MOC_LITERAL(58, 795, 10), // "m_int_Data"
QT_MOC_LITERAL(59, 806, 13), // "mode_int_Data"
QT_MOC_LITERAL(60, 820, 12), // "num_int_Data"
QT_MOC_LITERAL(61, 833, 16), // "equally_int_Data"
QT_MOC_LITERAL(62, 850, 18), // "direction_int_Data"
QT_MOC_LITERAL(63, 869, 13), // "zero_int_Data"
QT_MOC_LITERAL(64, 883, 16), // "currentPath_Data"
QT_MOC_LITERAL(65, 900, 28), // "combinatorics_name_Path_Data"
QT_MOC_LITERAL(66, 929, 12), // "formula_Data"
QT_MOC_LITERAL(67, 942, 10), // "close_Data"
QT_MOC_LITERAL(68, 953, 29), // "Placements_without_repetition"
QT_MOC_LITERAL(69, 983, 26), // "Placements_with_repetition"
QT_MOC_LITERAL(70, 1010, 31), // "Combinations_without_repetition"
QT_MOC_LITERAL(71, 1042, 28), // "Combinations_with_repetition"
QT_MOC_LITERAL(72, 1071, 32), // "Permutations_without_repetitions"
QT_MOC_LITERAL(73, 1104, 29), // "Permutations_with_repetitions"
QT_MOC_LITERAL(74, 1134, 27), // "on_pushButton_point_clicked"
QT_MOC_LITERAL(75, 1162, 30), // "on_pushButton_negation_clicked"
QT_MOC_LITERAL(76, 1193, 19), // "creating_the_number"
QT_MOC_LITERAL(77, 1213, 24), // "on_pushButton_AC_clicked"
QT_MOC_LITERAL(78, 1238, 24), // "on_pushButton_CE_clicked"
QT_MOC_LITERAL(79, 1263, 12), // "reset_number"
QT_MOC_LITERAL(80, 1276, 11), // "reset_first"
QT_MOC_LITERAL(81, 1288, 12), // "reset_second"
QT_MOC_LITERAL(82, 1301, 12), // "reset_result"
QT_MOC_LITERAL(83, 1314, 19), // "reset_operation_str"
QT_MOC_LITERAL(84, 1334, 7), // "reset_n"
QT_MOC_LITERAL(85, 1342, 7), // "reset_m"
QT_MOC_LITERAL(86, 1350, 7), // "reset_t"
QT_MOC_LITERAL(87, 1358, 11), // "reset_p_str"
QT_MOC_LITERAL(88, 1370, 12), // "reset_p_char"
QT_MOC_LITERAL(89, 1383, 26), // "on_pushButton_plus_clicked"
QT_MOC_LITERAL(90, 1410, 27), // "on_pushButton_minus_clicked"
QT_MOC_LITERAL(91, 1438, 30), // "on_pushButton_multiply_clicked"
QT_MOC_LITERAL(92, 1469, 27), // "on_pushButton_share_clicked"
QT_MOC_LITERAL(93, 1497, 28), // "on_pushButton_degree_clicked"
QT_MOC_LITERAL(94, 1526, 26), // "on_pushButton_root_clicked"
QT_MOC_LITERAL(95, 1553, 28), // "on_pushButton_root_2_clicked"
QT_MOC_LITERAL(96, 1582, 30), // "on_pushButton_degree_2_clicked"
QT_MOC_LITERAL(97, 1613, 31), // "on_pushButton_factorial_clicked"
QT_MOC_LITERAL(98, 1645, 28), // "on_pushButton_result_clicked"
QT_MOC_LITERAL(99, 1674, 9), // "factorial"
QT_MOC_LITERAL(100, 1684, 25), // "Arithmetic_simplification"
QT_MOC_LITERAL(101, 1710, 27), // "Arithmetic_simplification_2"
QT_MOC_LITERAL(102, 1738, 28), // "One_operation_simplification"
QT_MOC_LITERAL(103, 1767, 30), // "One_operation_simplification_2"
QT_MOC_LITERAL(104, 1798, 35), // "simplification_of_the_combina..."
QT_MOC_LITERAL(105, 1834, 23), // "on_pushButton_n_clicked"
QT_MOC_LITERAL(106, 1858, 23), // "on_pushButton_m_clicked"
QT_MOC_LITERAL(107, 1882, 25), // "on_pushButton_RNU_clicked"
QT_MOC_LITERAL(108, 1908, 25), // "on_pushButton_RND_clicked"
QT_MOC_LITERAL(109, 1934, 10), // "adjustment"
QT_MOC_LITERAL(110, 1945, 17), // "other_application"
QT_MOC_LITERAL(111, 1963, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(112, 1985, 27), // "on_pushButton_tasks_clicked"
QT_MOC_LITERAL(113, 2013, 26), // "on_pushButton_left_clicked"
QT_MOC_LITERAL(114, 2040, 27), // "on_pushButton_right_clicked"
QT_MOC_LITERAL(115, 2068, 12), // "secondwindow"
QT_MOC_LITERAL(116, 2081, 14), // "factorial_test"
QT_MOC_LITERAL(117, 2096, 1), // "n"
QT_MOC_LITERAL(118, 2098, 7), // "bigLine"
QT_MOC_LITERAL(119, 2106, 8), // "int[500]"
QT_MOC_LITERAL(120, 2115, 1), // "I"
QT_MOC_LITERAL(121, 2117, 31), // "on_pushButton_bernoulle_clicked"
QT_MOC_LITERAL(122, 2149, 32), // "on_pushButton_polynomial_clicked"
QT_MOC_LITERAL(123, 2182, 29), // "on_pushButton_poisson_clicked"
QT_MOC_LITERAL(124, 2212, 29), // "on_pushButton_tasks_2_clicked"
QT_MOC_LITERAL(125, 2242, 29), // "on_pushButton_tasks_3_clicked"
QT_MOC_LITERAL(126, 2272, 29), // "on_pushButton_tasks_4_clicked"
QT_MOC_LITERAL(127, 2302, 29) // "on_pushButton_tasks_5_clicked"

    },
    "MainWindow\0number_str_Data\0\0str\0"
    "first_str_Data\0second_str_Data\0"
    "result_str_Data\0n_str_Data\0m_str_Data\0"
    "operation_str_Data\0key_str_Data\0"
    "p1_str_Data\0p2_str_Data\0p3_str_Data\0"
    "p4_str_Data\0p5_str_Data\0t0_int_Data\0"
    "i\0t1_int_Data\0t2_int_Data\0t3_int_Data\0"
    "xC_int_Data\0yC_int_Data\0xGC_int_Data\0"
    "yGC_int_Data\0xGCW_int_Data\0yGCW_int_Data\0"
    "xC_int_B_Data\0yC_int_B_Data\0xGC_int_B_Data\0"
    "yGC_int_B_Data\0xGCW_int_B_Data\0"
    "yGCW_int_B_Data\0xC_int_Py_Data\0"
    "yC_int_Py_Data\0xGC_int_Py_Data\0"
    "yGC_int_Py_Data\0xGCW_int_Py_Data\0"
    "yGCW_int_Py_Data\0xC_int_Po_Data\0"
    "yC_int_Po_Data\0xGC_int_Po_Data\0"
    "yGC_int_Po_Data\0xGCW_int_Po_Data\0"
    "yGCW_int_Po_Data\0n_char_Data\0m_char_Data\0"
    "number_double_Data\0d\0first_double_Data\0"
    "second_double_Data\0result_double_Data\0"
    "n_double_Data\0m_double_Data\0"
    "number_size_int_Data\0first_int_Data\0"
    "result_int_Data\0n_int_Data\0m_int_Data\0"
    "mode_int_Data\0num_int_Data\0equally_int_Data\0"
    "direction_int_Data\0zero_int_Data\0"
    "currentPath_Data\0combinatorics_name_Path_Data\0"
    "formula_Data\0close_Data\0"
    "Placements_without_repetition\0"
    "Placements_with_repetition\0"
    "Combinations_without_repetition\0"
    "Combinations_with_repetition\0"
    "Permutations_without_repetitions\0"
    "Permutations_with_repetitions\0"
    "on_pushButton_point_clicked\0"
    "on_pushButton_negation_clicked\0"
    "creating_the_number\0on_pushButton_AC_clicked\0"
    "on_pushButton_CE_clicked\0reset_number\0"
    "reset_first\0reset_second\0reset_result\0"
    "reset_operation_str\0reset_n\0reset_m\0"
    "reset_t\0reset_p_str\0reset_p_char\0"
    "on_pushButton_plus_clicked\0"
    "on_pushButton_minus_clicked\0"
    "on_pushButton_multiply_clicked\0"
    "on_pushButton_share_clicked\0"
    "on_pushButton_degree_clicked\0"
    "on_pushButton_root_clicked\0"
    "on_pushButton_root_2_clicked\0"
    "on_pushButton_degree_2_clicked\0"
    "on_pushButton_factorial_clicked\0"
    "on_pushButton_result_clicked\0factorial\0"
    "Arithmetic_simplification\0"
    "Arithmetic_simplification_2\0"
    "One_operation_simplification\0"
    "One_operation_simplification_2\0"
    "simplification_of_the_combinatorics\0"
    "on_pushButton_n_clicked\0on_pushButton_m_clicked\0"
    "on_pushButton_RNU_clicked\0"
    "on_pushButton_RND_clicked\0adjustment\0"
    "other_application\0on_pushButton_clicked\0"
    "on_pushButton_tasks_clicked\0"
    "on_pushButton_left_clicked\0"
    "on_pushButton_right_clicked\0secondwindow\0"
    "factorial_test\0n\0bigLine\0int[500]\0I\0"
    "on_pushButton_bernoulle_clicked\0"
    "on_pushButton_polynomial_clicked\0"
    "on_pushButton_poisson_clicked\0"
    "on_pushButton_tasks_2_clicked\0"
    "on_pushButton_tasks_3_clicked\0"
    "on_pushButton_tasks_4_clicked\0"
    "on_pushButton_tasks_5_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
     120,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      63,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  614,    2, 0x06 /* Public */,
       4,    1,  617,    2, 0x06 /* Public */,
       5,    1,  620,    2, 0x06 /* Public */,
       6,    1,  623,    2, 0x06 /* Public */,
       7,    1,  626,    2, 0x06 /* Public */,
       8,    1,  629,    2, 0x06 /* Public */,
       9,    1,  632,    2, 0x06 /* Public */,
      10,    1,  635,    2, 0x06 /* Public */,
      11,    1,  638,    2, 0x06 /* Public */,
      12,    1,  641,    2, 0x06 /* Public */,
      13,    1,  644,    2, 0x06 /* Public */,
      14,    1,  647,    2, 0x06 /* Public */,
      15,    1,  650,    2, 0x06 /* Public */,
      16,    1,  653,    2, 0x06 /* Public */,
      18,    1,  656,    2, 0x06 /* Public */,
      19,    1,  659,    2, 0x06 /* Public */,
      20,    1,  662,    2, 0x06 /* Public */,
      21,    1,  665,    2, 0x06 /* Public */,
      22,    1,  668,    2, 0x06 /* Public */,
      23,    1,  671,    2, 0x06 /* Public */,
      24,    1,  674,    2, 0x06 /* Public */,
      25,    1,  677,    2, 0x06 /* Public */,
      26,    1,  680,    2, 0x06 /* Public */,
      27,    1,  683,    2, 0x06 /* Public */,
      28,    1,  686,    2, 0x06 /* Public */,
      29,    1,  689,    2, 0x06 /* Public */,
      30,    1,  692,    2, 0x06 /* Public */,
      31,    1,  695,    2, 0x06 /* Public */,
      32,    1,  698,    2, 0x06 /* Public */,
      33,    1,  701,    2, 0x06 /* Public */,
      34,    1,  704,    2, 0x06 /* Public */,
      35,    1,  707,    2, 0x06 /* Public */,
      36,    1,  710,    2, 0x06 /* Public */,
      37,    1,  713,    2, 0x06 /* Public */,
      38,    1,  716,    2, 0x06 /* Public */,
      39,    1,  719,    2, 0x06 /* Public */,
      40,    1,  722,    2, 0x06 /* Public */,
      41,    1,  725,    2, 0x06 /* Public */,
      42,    1,  728,    2, 0x06 /* Public */,
      43,    1,  731,    2, 0x06 /* Public */,
      44,    1,  734,    2, 0x06 /* Public */,
      45,    1,  737,    2, 0x06 /* Public */,
      46,    1,  740,    2, 0x06 /* Public */,
      47,    1,  743,    2, 0x06 /* Public */,
      49,    1,  746,    2, 0x06 /* Public */,
      50,    1,  749,    2, 0x06 /* Public */,
      51,    1,  752,    2, 0x06 /* Public */,
      52,    1,  755,    2, 0x06 /* Public */,
      53,    1,  758,    2, 0x06 /* Public */,
      54,    1,  761,    2, 0x06 /* Public */,
      55,    1,  764,    2, 0x06 /* Public */,
      56,    1,  767,    2, 0x06 /* Public */,
      57,    1,  770,    2, 0x06 /* Public */,
      58,    1,  773,    2, 0x06 /* Public */,
      59,    1,  776,    2, 0x06 /* Public */,
      60,    1,  779,    2, 0x06 /* Public */,
      61,    1,  782,    2, 0x06 /* Public */,
      62,    1,  785,    2, 0x06 /* Public */,
      63,    1,  788,    2, 0x06 /* Public */,
      64,    1,  791,    2, 0x06 /* Public */,
      65,    1,  794,    2, 0x06 /* Public */,
      66,    1,  797,    2, 0x06 /* Public */,
      67,    1,  800,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      68,    0,  803,    2, 0x08 /* Private */,
      69,    0,  804,    2, 0x08 /* Private */,
      70,    0,  805,    2, 0x08 /* Private */,
      71,    0,  806,    2, 0x08 /* Private */,
      72,    0,  807,    2, 0x08 /* Private */,
      73,    0,  808,    2, 0x08 /* Private */,
      74,    0,  809,    2, 0x08 /* Private */,
      75,    0,  810,    2, 0x08 /* Private */,
      76,    0,  811,    2, 0x08 /* Private */,
      77,    0,  812,    2, 0x08 /* Private */,
      78,    0,  813,    2, 0x08 /* Private */,
      79,    0,  814,    2, 0x08 /* Private */,
      80,    0,  815,    2, 0x08 /* Private */,
      81,    0,  816,    2, 0x08 /* Private */,
      82,    0,  817,    2, 0x08 /* Private */,
      83,    0,  818,    2, 0x08 /* Private */,
      84,    0,  819,    2, 0x08 /* Private */,
      85,    0,  820,    2, 0x08 /* Private */,
      86,    0,  821,    2, 0x08 /* Private */,
      87,    0,  822,    2, 0x08 /* Private */,
      88,    0,  823,    2, 0x08 /* Private */,
      89,    0,  824,    2, 0x08 /* Private */,
      90,    0,  825,    2, 0x08 /* Private */,
      91,    0,  826,    2, 0x08 /* Private */,
      92,    0,  827,    2, 0x08 /* Private */,
      93,    0,  828,    2, 0x08 /* Private */,
      94,    0,  829,    2, 0x08 /* Private */,
      95,    0,  830,    2, 0x08 /* Private */,
      96,    0,  831,    2, 0x08 /* Private */,
      97,    0,  832,    2, 0x08 /* Private */,
      98,    0,  833,    2, 0x08 /* Private */,
      99,    1,  834,    2, 0x08 /* Private */,
     100,    0,  837,    2, 0x08 /* Private */,
     101,    0,  838,    2, 0x08 /* Private */,
     102,    0,  839,    2, 0x08 /* Private */,
     103,    0,  840,    2, 0x08 /* Private */,
     104,    0,  841,    2, 0x08 /* Private */,
     105,    0,  842,    2, 0x08 /* Private */,
     106,    0,  843,    2, 0x08 /* Private */,
     107,    0,  844,    2, 0x08 /* Private */,
     108,    0,  845,    2, 0x08 /* Private */,
     109,    0,  846,    2, 0x08 /* Private */,
     110,    0,  847,    2, 0x08 /* Private */,
     111,    0,  848,    2, 0x08 /* Private */,
     112,    0,  849,    2, 0x08 /* Private */,
     113,    0,  850,    2, 0x08 /* Private */,
     114,    0,  851,    2, 0x08 /* Private */,
     115,    0,  852,    2, 0x08 /* Private */,
     116,    1,  853,    2, 0x08 /* Private */,
     118,    1,  856,    2, 0x08 /* Private */,
     121,    0,  859,    2, 0x08 /* Private */,
     122,    0,  860,    2, 0x08 /* Private */,
     123,    0,  861,    2, 0x08 /* Private */,
     124,    0,  862,    2, 0x08 /* Private */,
     125,    0,  863,    2, 0x08 /* Private */,
     126,    0,  864,    2, 0x08 /* Private */,
     127,    0,  865,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Double,   48,
    QMetaType::Void, QMetaType::Double,   48,
    QMetaType::Void, QMetaType::Double,   48,
    QMetaType::Void, QMetaType::Double,   48,
    QMetaType::Void, QMetaType::Double,   48,
    QMetaType::Void, QMetaType::Double,   48,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Int, QMetaType::Int,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::QString, QMetaType::Int,  117,
    QMetaType::QString, 0x80000000 | 119,  120,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->number_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->first_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->second_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->result_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->n_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->m_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->operation_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->key_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->p1_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->p2_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 10: _t->p3_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->p4_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->p5_str_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->t0_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->t1_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->t2_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->t3_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->xC_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->yC_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->xGC_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->yGC_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->xGCW_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->yGCW_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->xC_int_B_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->yC_int_B_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 25: _t->xGC_int_B_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->yGC_int_B_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->xGCW_int_B_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->yGCW_int_B_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->xC_int_Py_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->yC_int_Py_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 31: _t->xGC_int_Py_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 32: _t->yGC_int_Py_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->xGCW_int_Py_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->yGCW_int_Py_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: _t->xC_int_Po_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 36: _t->yC_int_Po_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 37: _t->xGC_int_Po_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 38: _t->yGC_int_Po_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 39: _t->xGCW_int_Po_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 40: _t->yGCW_int_Po_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 41: _t->n_char_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 42: _t->m_char_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 43: _t->number_double_Data((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 44: _t->first_double_Data((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 45: _t->second_double_Data((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 46: _t->result_double_Data((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 47: _t->n_double_Data((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 48: _t->m_double_Data((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 49: _t->number_size_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 50: _t->first_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 51: _t->result_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 52: _t->n_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 53: _t->m_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 54: _t->mode_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 55: _t->num_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 56: _t->equally_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 57: _t->direction_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 58: _t->zero_int_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 59: _t->currentPath_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 60: _t->combinatorics_name_Path_Data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 61: _t->formula_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 62: _t->close_Data((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 63: _t->Placements_without_repetition(); break;
        case 64: _t->Placements_with_repetition(); break;
        case 65: _t->Combinations_without_repetition(); break;
        case 66: _t->Combinations_with_repetition(); break;
        case 67: _t->Permutations_without_repetitions(); break;
        case 68: _t->Permutations_with_repetitions(); break;
        case 69: _t->on_pushButton_point_clicked(); break;
        case 70: _t->on_pushButton_negation_clicked(); break;
        case 71: _t->creating_the_number(); break;
        case 72: _t->on_pushButton_AC_clicked(); break;
        case 73: _t->on_pushButton_CE_clicked(); break;
        case 74: _t->reset_number(); break;
        case 75: _t->reset_first(); break;
        case 76: _t->reset_second(); break;
        case 77: _t->reset_result(); break;
        case 78: _t->reset_operation_str(); break;
        case 79: _t->reset_n(); break;
        case 80: _t->reset_m(); break;
        case 81: _t->reset_t(); break;
        case 82: _t->reset_p_str(); break;
        case 83: _t->reset_p_char(); break;
        case 84: _t->on_pushButton_plus_clicked(); break;
        case 85: _t->on_pushButton_minus_clicked(); break;
        case 86: _t->on_pushButton_multiply_clicked(); break;
        case 87: _t->on_pushButton_share_clicked(); break;
        case 88: _t->on_pushButton_degree_clicked(); break;
        case 89: _t->on_pushButton_root_clicked(); break;
        case 90: _t->on_pushButton_root_2_clicked(); break;
        case 91: _t->on_pushButton_degree_2_clicked(); break;
        case 92: _t->on_pushButton_factorial_clicked(); break;
        case 93: _t->on_pushButton_result_clicked(); break;
        case 94: { int _r = _t->factorial((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 95: _t->Arithmetic_simplification(); break;
        case 96: _t->Arithmetic_simplification_2(); break;
        case 97: _t->One_operation_simplification(); break;
        case 98: _t->One_operation_simplification_2(); break;
        case 99: _t->simplification_of_the_combinatorics(); break;
        case 100: _t->on_pushButton_n_clicked(); break;
        case 101: _t->on_pushButton_m_clicked(); break;
        case 102: _t->on_pushButton_RNU_clicked(); break;
        case 103: _t->on_pushButton_RND_clicked(); break;
        case 104: _t->adjustment(); break;
        case 105: _t->other_application(); break;
        case 106: _t->on_pushButton_clicked(); break;
        case 107: _t->on_pushButton_tasks_clicked(); break;
        case 108: _t->on_pushButton_left_clicked(); break;
        case 109: _t->on_pushButton_right_clicked(); break;
        case 110: _t->secondwindow(); break;
        case 111: { QString _r = _t->factorial_test((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 112: { QString _r = _t->bigLine((*reinterpret_cast< int(*)[500]>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 113: _t->on_pushButton_bernoulle_clicked(); break;
        case 114: _t->on_pushButton_polynomial_clicked(); break;
        case 115: _t->on_pushButton_poisson_clicked(); break;
        case 116: _t->on_pushButton_tasks_2_clicked(); break;
        case 117: _t->on_pushButton_tasks_3_clicked(); break;
        case 118: _t->on_pushButton_tasks_4_clicked(); break;
        case 119: _t->on_pushButton_tasks_5_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::number_str_Data)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::first_str_Data)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::second_str_Data)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::result_str_Data)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::n_str_Data)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::m_str_Data)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::operation_str_Data)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::key_str_Data)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::p1_str_Data)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::p2_str_Data)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::p3_str_Data)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::p4_str_Data)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::p5_str_Data)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::t0_int_Data)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::t1_int_Data)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::t2_int_Data)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::t3_int_Data)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xC_int_Data)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yC_int_Data)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xGC_int_Data)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yGC_int_Data)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xGCW_int_Data)) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yGCW_int_Data)) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xC_int_B_Data)) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yC_int_B_Data)) {
                *result = 24;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xGC_int_B_Data)) {
                *result = 25;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yGC_int_B_Data)) {
                *result = 26;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xGCW_int_B_Data)) {
                *result = 27;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yGCW_int_B_Data)) {
                *result = 28;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xC_int_Py_Data)) {
                *result = 29;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yC_int_Py_Data)) {
                *result = 30;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xGC_int_Py_Data)) {
                *result = 31;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yGC_int_Py_Data)) {
                *result = 32;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xGCW_int_Py_Data)) {
                *result = 33;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yGCW_int_Py_Data)) {
                *result = 34;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xC_int_Po_Data)) {
                *result = 35;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yC_int_Po_Data)) {
                *result = 36;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xGC_int_Po_Data)) {
                *result = 37;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yGC_int_Po_Data)) {
                *result = 38;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::xGCW_int_Po_Data)) {
                *result = 39;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::yGCW_int_Po_Data)) {
                *result = 40;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::n_char_Data)) {
                *result = 41;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::m_char_Data)) {
                *result = 42;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::number_double_Data)) {
                *result = 43;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::first_double_Data)) {
                *result = 44;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::second_double_Data)) {
                *result = 45;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::result_double_Data)) {
                *result = 46;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::n_double_Data)) {
                *result = 47;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::m_double_Data)) {
                *result = 48;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::number_size_int_Data)) {
                *result = 49;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::first_int_Data)) {
                *result = 50;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::result_int_Data)) {
                *result = 51;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::n_int_Data)) {
                *result = 52;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::m_int_Data)) {
                *result = 53;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::mode_int_Data)) {
                *result = 54;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::num_int_Data)) {
                *result = 55;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::equally_int_Data)) {
                *result = 56;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::direction_int_Data)) {
                *result = 57;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::zero_int_Data)) {
                *result = 58;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::currentPath_Data)) {
                *result = 59;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::combinatorics_name_Path_Data)) {
                *result = 60;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::formula_Data)) {
                *result = 61;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::close_Data)) {
                *result = 62;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 120)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 120;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 120)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 120;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::number_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::first_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::second_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::result_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MainWindow::n_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MainWindow::m_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void MainWindow::operation_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void MainWindow::key_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void MainWindow::p1_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void MainWindow::p2_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void MainWindow::p3_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void MainWindow::p4_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void MainWindow::p5_str_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void MainWindow::t0_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void MainWindow::t1_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void MainWindow::t2_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void MainWindow::t3_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void MainWindow::xC_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void MainWindow::yC_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void MainWindow::xGC_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void MainWindow::yGC_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void MainWindow::xGCW_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 21, _a);
}

// SIGNAL 22
void MainWindow::yGCW_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void MainWindow::xC_int_B_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 23, _a);
}

// SIGNAL 24
void MainWindow::yC_int_B_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 24, _a);
}

// SIGNAL 25
void MainWindow::xGC_int_B_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 25, _a);
}

// SIGNAL 26
void MainWindow::yGC_int_B_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 26, _a);
}

// SIGNAL 27
void MainWindow::xGCW_int_B_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 27, _a);
}

// SIGNAL 28
void MainWindow::yGCW_int_B_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 28, _a);
}

// SIGNAL 29
void MainWindow::xC_int_Py_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 29, _a);
}

// SIGNAL 30
void MainWindow::yC_int_Py_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 30, _a);
}

// SIGNAL 31
void MainWindow::xGC_int_Py_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 31, _a);
}

// SIGNAL 32
void MainWindow::yGC_int_Py_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 32, _a);
}

// SIGNAL 33
void MainWindow::xGCW_int_Py_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 33, _a);
}

// SIGNAL 34
void MainWindow::yGCW_int_Py_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 34, _a);
}

// SIGNAL 35
void MainWindow::xC_int_Po_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 35, _a);
}

// SIGNAL 36
void MainWindow::yC_int_Po_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 36, _a);
}

// SIGNAL 37
void MainWindow::xGC_int_Po_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 37, _a);
}

// SIGNAL 38
void MainWindow::yGC_int_Po_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 38, _a);
}

// SIGNAL 39
void MainWindow::xGCW_int_Po_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 39, _a);
}

// SIGNAL 40
void MainWindow::yGCW_int_Po_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 40, _a);
}

// SIGNAL 41
void MainWindow::n_char_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 41, _a);
}

// SIGNAL 42
void MainWindow::m_char_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 42, _a);
}

// SIGNAL 43
void MainWindow::number_double_Data(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 43, _a);
}

// SIGNAL 44
void MainWindow::first_double_Data(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 44, _a);
}

// SIGNAL 45
void MainWindow::second_double_Data(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 45, _a);
}

// SIGNAL 46
void MainWindow::result_double_Data(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 46, _a);
}

// SIGNAL 47
void MainWindow::n_double_Data(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 47, _a);
}

// SIGNAL 48
void MainWindow::m_double_Data(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 48, _a);
}

// SIGNAL 49
void MainWindow::number_size_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 49, _a);
}

// SIGNAL 50
void MainWindow::first_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 50, _a);
}

// SIGNAL 51
void MainWindow::result_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 51, _a);
}

// SIGNAL 52
void MainWindow::n_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 52, _a);
}

// SIGNAL 53
void MainWindow::m_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 53, _a);
}

// SIGNAL 54
void MainWindow::mode_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 54, _a);
}

// SIGNAL 55
void MainWindow::num_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 55, _a);
}

// SIGNAL 56
void MainWindow::equally_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 56, _a);
}

// SIGNAL 57
void MainWindow::direction_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 57, _a);
}

// SIGNAL 58
void MainWindow::zero_int_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 58, _a);
}

// SIGNAL 59
void MainWindow::currentPath_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 59, _a);
}

// SIGNAL 60
void MainWindow::combinatorics_name_Path_Data(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 60, _a);
}

// SIGNAL 61
void MainWindow::formula_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 61, _a);
}

// SIGNAL 62
void MainWindow::close_Data(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 62, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
