/****************************************************************************
** Meta object code from reading C++ file 'poisson.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Calculator/poisson.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'poisson.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Poisson_t {
    QByteArrayData data[20];
    char stringdata0[238];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Poisson_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Poisson_t qt_meta_stringdata_Poisson = {
    {
QT_MOC_LITERAL(0, 0, 7), // "Poisson"
QT_MOC_LITERAL(1, 8, 32), // "on_pushButton_decision_2_clicked"
QT_MOC_LITERAL(2, 41, 0), // ""
QT_MOC_LITERAL(3, 42, 9), // "factorial"
QT_MOC_LITERAL(4, 52, 1), // "i"
QT_MOC_LITERAL(5, 54, 14), // "exarticulation"
QT_MOC_LITERAL(6, 69, 3), // "str"
QT_MOC_LITERAL(7, 73, 3), // "num"
QT_MOC_LITERAL(8, 77, 7), // "poisson"
QT_MOC_LITERAL(9, 85, 1), // "n"
QT_MOC_LITERAL(10, 87, 1), // "m"
QT_MOC_LITERAL(11, 89, 1), // "p"
QT_MOC_LITERAL(12, 91, 17), // "close_recieveData"
QT_MOC_LITERAL(13, 109, 18), // "xC_int_recieveData"
QT_MOC_LITERAL(14, 128, 18), // "yC_int_recieveData"
QT_MOC_LITERAL(15, 147, 19), // "xGC_int_recieveData"
QT_MOC_LITERAL(16, 167, 19), // "yGC_int_recieveData"
QT_MOC_LITERAL(17, 187, 20), // "xGCW_int_recieveData"
QT_MOC_LITERAL(18, 208, 20), // "yGCW_int_recieveData"
QT_MOC_LITERAL(19, 229, 8) // "location"

    },
    "Poisson\0on_pushButton_decision_2_clicked\0"
    "\0factorial\0i\0exarticulation\0str\0num\0"
    "poisson\0n\0m\0p\0close_recieveData\0"
    "xC_int_recieveData\0yC_int_recieveData\0"
    "xGC_int_recieveData\0yGC_int_recieveData\0"
    "xGCW_int_recieveData\0yGCW_int_recieveData\0"
    "location"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Poisson[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x08 /* Private */,
       3,    1,   75,    2, 0x08 /* Private */,
       5,    2,   78,    2, 0x08 /* Private */,
       8,    3,   83,    2, 0x08 /* Private */,
      12,    1,   90,    2, 0x08 /* Private */,
      13,    1,   93,    2, 0x08 /* Private */,
      14,    1,   96,    2, 0x08 /* Private */,
      15,    1,   99,    2, 0x08 /* Private */,
      16,    1,  102,    2, 0x08 /* Private */,
      17,    1,  105,    2, 0x08 /* Private */,
      18,    1,  108,    2, 0x08 /* Private */,
      19,    0,  111,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Int, QMetaType::Int,    4,
    QMetaType::Int, QMetaType::QString, QMetaType::Int,    6,    7,
    QMetaType::Double, QMetaType::Int, QMetaType::Int, QMetaType::Double,    9,   10,   11,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,

       0        // eod
};

void Poisson::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Poisson *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_decision_2_clicked(); break;
        case 1: { int _r = _t->factorial((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 2: { int _r = _t->exarticulation((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 3: { double _r = _t->poisson((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = std::move(_r); }  break;
        case 4: _t->close_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->xC_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->yC_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->xGC_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->yGC_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->xGCW_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->yGCW_int_recieveData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->location(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Poisson::staticMetaObject = { {
    &QDialog::staticMetaObject,
    qt_meta_stringdata_Poisson.data,
    qt_meta_data_Poisson,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Poisson::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Poisson::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Poisson.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int Poisson::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
